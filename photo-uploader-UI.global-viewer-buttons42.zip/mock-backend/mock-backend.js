/* mock-backend/mock-backend.js
 * "Backend" without servers/deps. Works under file://
 * - Hydrates window.CARS_DATA from localStorage (if present)
 * - Exposes Promise-based API in window.MockBackend
 */
(function () {
  const STORAGE_KEY = "mock_backend_cars_v1";

  const clone = (obj) => JSON.parse(JSON.stringify(obj));

  function loadCarsFromStorage() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : null;
    } catch (_) {
      return null;
    }
  }

  function saveCarsToStorage(cars) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(cars));
    } catch (_) {
      // ignore (quota/private mode)
    }
  }

  const delay = (ms) => new Promise((r) => setTimeout(r, ms));

  // Backwards compatibility for existing UI:
  const stored = loadCarsFromStorage();
  if (stored) {
    window.CARS_DATA = stored;
  } else if (!Array.isArray(window.CARS_DATA)) {
    window.CARS_DATA = [];
  }

  async function login({ username, password }, { latencyMs = 0 } = {}) {
    if (latencyMs) await delay(latencyMs);

    // Minimal mock rule: allow any non-empty credentials (or admin/admin)
    const ok = (username === "admin" && password === "admin") || (username && password);
    if (!ok) {
      const err = new Error("Invalid credentials");
      err.code = "AUTH_INVALID";
      throw err;
    }
    return { token: "mock-token", user: { username } };
  }

  async function listCars({ latencyMs = 0 } = {}) {
    if (latencyMs) await delay(latencyMs);
    return clone(window.CARS_DATA);
  }

  async function getCarById(id, { latencyMs = 0 } = {}) {
    if (latencyMs) await delay(latencyMs);
    const car = window.CARS_DATA.find((c) => String(c.id) === String(id));
    return car ? clone(car) : null;
  }

  async function updateCar(id, patch, { latencyMs = 0 } = {}) {
    if (latencyMs) await delay(latencyMs);

    const idx = window.CARS_DATA.findIndex((c) => String(c.id) === String(id));
    if (idx === -1) {
      const err = new Error("Car not found");
      err.code = "NOT_FOUND";
      throw err;
    }

    window.CARS_DATA[idx] = Object.assign({}, window.CARS_DATA[idx], patch);
    saveCarsToStorage(window.CARS_DATA);
    return clone(window.CARS_DATA[idx]);
  }

  async function resetCars({ latencyMs = 0 } = {}) {
    if (latencyMs) await delay(latencyMs);
    try { localStorage.removeItem(STORAGE_KEY); } catch (_) {}
    return true;
  }

  window.MockBackend = {
    auth: { login },
    cars: { list: listCars, getById: getCarById, update: updateCar, reset: resetCars },
    _storageKey: STORAGE_KEY,
    _delay: delay,
  };
})();
