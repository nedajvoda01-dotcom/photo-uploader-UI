/* frontend/js/api.js
 * Единственная точка доступа к данным.
 * Сейчас: вызывает window.MockBackend (без серверов, file:// friendly).
 * Потом: можно заменить реализацией HTTP (fetch).
 */
(function () {
  const hasMock = typeof window.MockBackend !== "undefined";

  async function login(username, password) {
    if (!hasMock) throw new Error("Backend not configured");
    return window.MockBackend.auth.login({ username, password }, { latencyMs: 120 });
  }

  async function listCars() {
    if (!hasMock) throw new Error("Backend not configured");
    return window.MockBackend.cars.list({ latencyMs: 120 });
  }

  async function updateCar(id, patch) {
    if (!hasMock) throw new Error("Backend not configured");
    return window.MockBackend.cars.update(id, patch, { latencyMs: 120 });
  }

  window.API = { login, listCars, updateCar };
})();
