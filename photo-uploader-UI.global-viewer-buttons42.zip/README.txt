Запуск: просто открой index.html (двойной клик). Никаких серверов/зависимостей.

Структура:
- index.html            — точка входа
- frontend/             — фронтенд (css/js)
- mock-backend/         — мок-бэк без сервера
  - data/cars-data.js   — данные (window.CARS_DATA)
  - mock-backend.js     — API (window.MockBackend) + localStorage
- legacy/               — старые файлы (не используются)
